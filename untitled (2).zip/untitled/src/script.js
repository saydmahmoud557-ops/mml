window.addEventListener("scroll",()=>{

let header=document.querySelector("header");

if(window.scrollY>50){

header.style.background="#000";

}else{

header.style.background="rgba(0,0,0,.5)";

}

});
function addToCart(name,price){

let cart=JSON.parse(localStorage.getItem("cart"))||[];

cart.push({

name:name,

price:price

});

localStorage.setItem("cart",JSON.stringify(cart));

alert("تمت إضافة المنتج إلى السلة");

}